package com.infob.employeemanagement.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.infob.employeemanagement.entity.Employee;

@Service
public interface EmployeeService {

	public Employee saveEmp(Employee emp);
	public List<Employee> getAllEmp();
	public void deleteEmpById(int id) throws Exception;
	public Employee updateEmp(Employee emp, int id) throws Exception;
}
