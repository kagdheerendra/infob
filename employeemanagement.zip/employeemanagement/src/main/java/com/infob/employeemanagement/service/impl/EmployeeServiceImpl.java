package com.infob.employeemanagement.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infob.employeemanagement.entity.Employee;
import com.infob.employeemanagement.repository.EmployeeRepository;
import com.infob.employeemanagement.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	private EmployeeRepository empRepo;
	
	@Override
	public Employee saveEmp(Employee emp) {
		return empRepo.save(emp);
	}

	@Override
	public List<Employee> getAllEmp() {
		return empRepo.findAll();
	}

	@Override
	public void deleteEmpById(int id) throws Exception {
		Employee emp = empRepo.findById(id).orElseThrow(() -> new Exception("Employee not found with id : " + id));
		empRepo.delete(emp);
	}

	@Override
	public Employee updateEmp(Employee emp, int id) throws Exception{
		Employee employee = empRepo.findById(id).orElseThrow(() -> new Exception("Employee not found with id : " + id));
		employee.setEmpId(emp.getEmpId());
		employee.setName(emp.getName());
		employee.setMobileNumber(emp.getMobileNumber());
		employee.setEmailId(emp.getEmailId());
		return empRepo.save(employee);
	}

}
